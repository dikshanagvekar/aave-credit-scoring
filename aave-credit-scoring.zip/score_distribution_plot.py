import pandas as pd
import matplotlib.pyplot as plt
import os

# Load scored data
df = pd.read_csv('data/wallet_scores.csv')

# Create score bins (0–1000 in 100-point ranges)
bins = list(range(0, 1101, 100))
labels = [f"{i}-{i+99}" for i in bins[:-1]]
df['score_range'] = pd.cut(df['score'], bins=bins, labels=labels, include_lowest=True)

# Count values per bin
score_counts = df['score_range'].value_counts().sort_index()

# Plot
plt.figure(figsize=(10, 6))
score_counts.plot(kind='bar', color='skyblue')
plt.title('Wallet Score Distribution', fontsize=16)
plt.xlabel('Score Range')
plt.ylabel('Number of Wallets')
plt.xticks(rotation=45)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()

# Save
os.makedirs("assets", exist_ok=True)
plt.savefig('assets/score_distribution.png')
plt.show()
