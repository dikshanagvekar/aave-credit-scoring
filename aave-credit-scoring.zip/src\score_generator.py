import json
import pandas as pd
import argparse
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler
import joblib


def load_transactions(file_path):
    with open(file_path, 'r') as f:
        data = json.load(f)

    # Normalize nested JSON
    df = pd.json_normalize(data)

    # Rename to match expected field names
    df.rename(columns={
        'userWallet': 'user',
        'actionData.amount': 'amount'
    }, inplace=True)

    return df


def preprocess_transactions(df):
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s', errors='coerce')
    return df


def engineer_features(df):
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s', errors='coerce')
    df['amount'] = pd.to_numeric(df['amount'], errors='coerce').fillna(0)

    grouped = df.groupby('user')
    features = grouped['action'].value_counts().unstack().fillna(0)

    features['total_txns'] = grouped.size()
    features['active_days'] = (grouped['timestamp'].max() - grouped['timestamp'].min()).dt.days + 1
    features['avg_borrow'] = grouped.apply(lambda x: x[x['action'] == 'borrow']['amount'].mean()).fillna(0)
    features['borrow_repay_ratio'] = grouped.apply(
        lambda x: x[x['action'] == 'borrow']['amount'].sum() / max(1, x[x['action'] == 'repay']['amount'].sum())
    ).fillna(0)

    return features.reset_index()


def train_model(features):
    y = features['reliable_score'] if 'reliable_score' in features.columns else None
    X = features.drop(columns=['user', 'reliable_score'], errors='ignore')

    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    if y is not None:
        model.fit(X_scaled, y)
    else:
        model.fit(X_scaled, [500] * len(X))  # Dummy target

    return model, scaler


def score_wallets(model, scaler, features):
    X = features.drop(columns=['user'], errors='ignore')
    X_scaled = scaler.transform(X)
    scores = model.predict(X_scaled)
    scores_scaled = MinMaxScaler(feature_range=(0, 1000)).fit_transform(scores.reshape(-1, 1))
    features['score'] = scores_scaled.round().astype(int)
    return features[['user', 'score']]


def main(input_path, output_path):
    df = load_transactions(input_path)
    df = preprocess_transactions(df)
    features = engineer_features(df)
    model, scaler = train_model(features)
    result = score_wallets(model, scaler, features)
    result.to_csv(output_path, index=False)
    print(f"Saved wallet scores to: {output_path}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help='Path to user_transactions.json')
    parser.add_argument('--output', required=True, help='Path to output CSV file')
    args = parser.parse_args()
    main(args.input, args.output)
